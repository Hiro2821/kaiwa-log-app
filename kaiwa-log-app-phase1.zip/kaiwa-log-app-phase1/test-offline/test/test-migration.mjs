// 【テスト専用】旧バージョン(v1)で保存されたデータが、
// アプリ更新後(v2)に自動的に正しく移行されるかを検証する。
// モジュールキャッシュの影響を避けるため、必ず独立したNodeプロセスとして実行すること
// （このファイル単体を `node test/test-migration.mjs` で実行する）。

import { installFakeIndexedDB } from './fakeIndexedDB.mjs';

installFakeIndexedDB();

let passCount = 0;
let failCount = 0;

function assert(condition, message) {
  if (condition) {
    passCount++;
    console.log(`  OK  ${message}`);
  } else {
    failCount++;
    console.error(`  NG  ${message}`);
  }
}

async function run() {
  const { DB_NAME } = await import('../../kaiwa-log-app/js/db/database.js');

  // 手順1: 「v1で運用していたDB」を模擬する。
  // 現行の js/db/database.js は使わず、当時のv1スキーマを直接IndexedDB APIで作成し、
  // 旧形式（nextTimeNotesが文字列配列）のレコードを1件・人物を1件入れておく。
  await new Promise((resolve, reject) => {
    const req = globalThis.indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = (event) => {
      const db = event.target.result;
      const records = db.createObjectStore('records', { keyPath: 'id' });
      records.createIndex('createdAt', 'createdAt');
      records.createIndex('personIds', 'personIds', { multiEntry: true });
      records.createIndex('groupIds', 'groupIds', { multiEntry: true });
      db.createObjectStore('people', { keyPath: 'id' }).createIndex('name', 'name');
      db.createObjectStore('groups', { keyPath: 'id' }).createIndex('name', 'name');
      db.createObjectStore('settings', { keyPath: 'key' });
    };
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction(['records', 'people'], 'readwrite');
      tx.objectStore('records').put({
        id: 'legacy-1',
        createdAt: '2026-01-01T00:00:00.000Z',
        updatedAt: '2026-01-01T00:00:00.000Z',
        personIds: [],
        groupIds: [],
        text: '旧バージョンで作成した記録',
        rawVoiceText: null,
        topics: ['旧話題'],
        keyPoints: [],
        nextTimeNotes: ['旧形式の文字列項目', '2つ目の項目'], // v1形式（文字列配列）
        title: '旧形式',
        deletedAt: null,
      });
      tx.objectStore('people').put({
        id: 'legacy-person-1',
        name: '移行前から登録済みの人物',
        memo: '',
        createdAt: '2026-01-01T00:00:00.000Z',
      });
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    };
    req.onerror = () => reject(req.error);
  });

  // 手順2: 現行コード(DB_VERSION=2)を通常どおり読み込んで開く。
  // = 実際のアプリ更新後の起動と同じ経路（onupgradeneeded に oldVersion:1 が渡る）。
  const { initDB } = await import('../../kaiwa-log-app/js/db/database.js');
  const { getRecord, listAllRecords } = await import('../../kaiwa-log-app/js/db/records.js');
  const { listPeople } = await import('../../kaiwa-log-app/js/db/people.js');

  await initDB();

  const migrated = await getRecord('legacy-1');
  assert(!!migrated, 'v1で作成した記録がv2移行後も存在する（データが失われていない）');
  assert(
    Array.isArray(migrated.nextTimeNotes) &&
      migrated.nextTimeNotes.length === 2 &&
      typeof migrated.nextTimeNotes[0] === 'object' &&
      typeof migrated.nextTimeNotes[0].id === 'string' &&
      migrated.nextTimeNotes[0].done === false &&
      migrated.nextTimeNotes[0].doneAt === null &&
      migrated.nextTimeNotes[0].text === '旧形式の文字列項目' &&
      migrated.nextTimeNotes[1].text === '2つ目の項目',
    '旧形式(文字列配列)が新形式({id,text,done,doneAt}の配列)に変換されている'
  );
  assert(migrated.text === '旧バージョンで作成した記録', '記録本文は変化しない');
  assert(migrated.topics.length === 1 && migrated.topics[0] === '旧話題', '話題など他のフィールドも変化しない');

  const allRecords = await listAllRecords();
  assert(allRecords.length === 1, 'マイグレーションで記録が増減しない');

  const people = await listPeople();
  assert(people.length === 1 && people[0].name === '移行前から登録済みの人物', '人物データもv2移行後にそのまま残る');

  // 手順3: 新しい記録を追加しても正しく新形式で保存されることを確認
  const { addRecord } = await import('../../kaiwa-log-app/js/db/records.js');
  const newRecord = await addRecord({
    text: '移行後に新規追加した記録',
    nextTimeNotes: [{ id: 'new-note-1', text: '新形式の項目', done: false, doneAt: null }],
  });
  assert(newRecord.nextTimeNotes[0].text === '新形式の項目', '移行後の新規追加データも正しく保存される');

  console.log(`\n[test-migration] 合計: ${passCount}件成功 / ${failCount}件失敗`);
  if (failCount > 0) process.exit(1);
}

run().catch((err) => {
  console.error('[test-migration] テスト実行中にエラーが発生しました:', err);
  process.exit(1);
});
