// 【テスト専用】基本機能のオフラインロジック検証（1つの接続内で完結するテスト）。
// 「アプリの再起動」を伴うテスト（マイグレーション・復元）は
// test-migration.mjs / test-fresh-restore.mjs を参照（別プロセスで実行）。

import { installFakeIndexedDB } from './fakeIndexedDB.mjs';

installFakeIndexedDB();

let passCount = 0;
let failCount = 0;

function assert(condition, message) {
  if (condition) {
    passCount++;
    console.log(`  OK  ${message}`);
  } else {
    failCount++;
    console.error(`  NG  ${message}`);
  }
}

async function run() {
  const peopleModule = await import('../../kaiwa-log-app/js/db/people.js');
  const groupsModule = await import('../../kaiwa-log-app/js/db/groups.js');
  const recordsModule = await import('../../kaiwa-log-app/js/db/records.js');
  const { generateTitle } = await import('../../kaiwa-log-app/js/lib/autoTitle.js');
  const { searchRecords } = await import('../../kaiwa-log-app/js/lib/search.js');
  const { getPersonSummary } = await import('../../kaiwa-log-app/js/lib/personSummary.js');
  const { mergePersonInto } = await import('../../kaiwa-log-app/js/lib/mergeEntity.js');
  const { buildBackupObject, importBackup } = await import('../../kaiwa-log-app/js/lib/backup.js');

  console.log('--- 1. 人物・グループの基本CRUD ---');
  const yamada = await peopleModule.addPerson({ name: '山田さん' });
  const tanaka = await peopleModule.addPerson({ name: '田中さん' });
  const uniGroup = await groupsModule.addGroup({ name: '大学の友人' });
  const people = await peopleModule.listPeople();
  assert(people.length === 2, '人物が2件登録されている');
  assert(people[0].name.localeCompare(people[1].name, 'ja') <= 0, '人物一覧が名前順になっている');

  console.log('--- 2. 記録の作成（人物あり／なし） ---');
  const rec1 = await recordsModule.addRecord({
    text: '山田さんと話した。来月北海道に旅行に行くらしい。',
    personIds: [yamada.id],
    groupIds: [uniGroup.id],
    topics: ['旅行'],
    nextTimeNotes: [{ id: 'note-a', text: '旅行の写真を見せてもらう', done: false, doneAt: null }],
  });
  const rec2 = await recordsModule.addRecord({
    text: '駅で偶然会った人に道を聞かれた。',
    personIds: [],
    groupIds: [],
  });
  assert(!!rec1.id && !!rec2.id, '記録が作成できる');
  assert(rec2.personIds.length === 0 && rec2.groupIds.length === 0, '人物・グループなしの記録が正常に作成できる');

  console.log('--- 3. 人物別・未分類の一覧取得 ---');
  const yamadaRecords = await recordsModule.listRecordsByPerson(yamada.id);
  assert(yamadaRecords.length === 1 && yamadaRecords[0].id === rec1.id, '人物別の一覧が正しい（multiEntryインデックス）');
  const unassigned = await recordsModule.listUnassignedRecords();
  assert(unassigned.length === 1 && unassigned[0].id === rec2.id, '未分類記録の一覧が正しい（空配列レコードの扱い）');

  console.log('--- 4. 論理削除・ゴミ箱・復元 ---');
  await recordsModule.softDeleteRecord(rec2.id);
  const allAfterDelete = await recordsModule.listAllRecords();
  assert(allAfterDelete.every((r) => r.id !== rec2.id), '論理削除後、通常一覧に出てこない');
  const trashed = await recordsModule.listTrashedRecords();
  assert(trashed.length === 1 && trashed[0].id === rec2.id, 'ゴミ箱に表示される');
  await recordsModule.restoreRecord(rec2.id);
  const allAfterRestore = await recordsModule.listAllRecords();
  assert(allAfterRestore.some((r) => r.id === rec2.id), '復元後、通常一覧に戻る');

  console.log('--- 5. 検索 ---');
  const allRecords = await recordsModule.listAllRecords();
  const searchByTopic = searchRecords(allRecords, '旅行');
  assert(searchByTopic.length === 1 && searchByTopic[0].id === rec1.id, '話題タグからの検索がヒットする');
  const searchByText = searchRecords(allRecords, '道を聞かれた');
  assert(searchByText.length === 1 && searchByText[0].id === rec2.id, '本文からの検索がヒットする');
  const searchByNextNote = searchRecords(allRecords, '写真を見せて');
  assert(searchByNextNote.length === 1 && searchByNextNote[0].id === rec1.id, '次回確認したいこと（オブジェクト形式）からの検索もヒットする');

  console.log('--- 6. タイトル自動生成 ---');
  assert(generateTitle('今日は天気がいい。散歩に行った。') === '今日は天気がいい。', '句点で一文を抜き出す');
  assert(generateTitle('あ'.repeat(40)) === 'あ'.repeat(24) + '…', '長い文は24文字+…に丸められる');
  assert(generateTitle('') === '', '空文字は空タイトルになる');

  console.log('--- 7. 人物詳細サマリー（最近の会話・話題・次回確認したいこと） ---');
  await recordsModule.addRecord({ text: '2回目の会話', personIds: [yamada.id], topics: ['旅行', '仕事'] });
  const summary = await getPersonSummary(yamada.id);
  assert(summary.totalCount === 2, '対象人物の記録数が正しい');
  assert(summary.recent[0].text === '2回目の会話', '最近の会話が新しい順になっている');
  assert(summary.topics.find((t) => t.topic === '旅行')?.count === 2, '話題の頻度集計が正しい');
  assert(
    summary.nextTimeNotes.length === 1 && summary.nextTimeNotes[0].text === '旅行の写真を見せてもらう' && summary.nextTimeNotes[0].done === false,
    '次回確認したいこと（未完了）が集約されている'
  );

  console.log('--- 8. 人物の統合（マージ） ---');
  await mergePersonInto(tanaka.id, yamada.id);
  const peopleAfterMerge = await peopleModule.listPeople();
  assert(!peopleAfterMerge.some((p) => p.id === tanaka.id), '統合元の人物が削除される');
  const summaryAfterMerge = await getPersonSummary(yamada.id);
  assert(summaryAfterMerge.totalCount === 2, '統合しても記録件数は変わらない（田中さんの記録は元々ないため）');

  console.log('--- 9. 次回確認したいことの完了トグル ---');
  const { toggleNextTimeNote } = recordsModule;
  const recForToggle = await recordsModule.addRecord({
    text: 'トグルテスト用の記録',
    personIds: [yamada.id],
    nextTimeNotes: [{ id: 'note-1', text: 'テスト項目', done: false, doneAt: null }],
  });
  await toggleNextTimeNote(recForToggle.id, 'note-1');
  const afterToggle = await recordsModule.getRecord(recForToggle.id);
  assert(afterToggle.nextTimeNotes[0].done === true, 'トグルでdoneがtrueになる');
  assert(!!afterToggle.nextTimeNotes[0].doneAt, 'トグルでdoneAtが記録される');
  await toggleNextTimeNote(recForToggle.id, 'note-1');
  const afterToggleBack = await recordsModule.getRecord(recForToggle.id);
  assert(afterToggleBack.nextTimeNotes[0].done === false, '再トグルでdoneがfalseに戻る');
  assert(afterToggleBack.nextTimeNotes[0].doneAt === null, '再トグルでdoneAtがnullに戻る');

  const summaryAfterToggle = await getPersonSummary(yamada.id);
  const pending = summaryAfterToggle.nextTimeNotes.filter((n) => !n.done);
  const done = summaryAfterToggle.nextTimeNotes.filter((n) => n.done);
  assert(pending.length + done.length === summaryAfterToggle.nextTimeNotes.length, '人物サマリーでも完了/未完了が分類できる');

  console.log('--- 10. JSONバックアップ: 追加読み込み(merge) と 復元(replace) の違い ---');
  // 重要: バックアップは「鈴木さんを追加する前」の状態で取得する
  const backupBeforeAddingSuzuki = await buildBackupObject();
  const suzuki = await peopleModule.addPerson({ name: '鈴木さん（バックアップ後に追加）' });

  const mergeResult = await importBackup(JSON.stringify(backupBeforeAddingSuzuki), { mode: 'merge' });
  assert(mergeResult.mode === 'merge', 'mergeモードが結果に反映される');
  const peopleAfterMerge2 = await peopleModule.listPeople();
  assert(peopleAfterMerge2.some((p) => p.id === suzuki.id), 'mergeでは、バックアップに無い既存データ（鈴木さん）が残る');

  const replaceResult = await importBackup(JSON.stringify(backupBeforeAddingSuzuki), { mode: 'replace' });
  assert(replaceResult.mode === 'replace', 'replaceモードが結果に反映される');
  const peopleAfterReplace = await peopleModule.listPeople();
  assert(!peopleAfterReplace.some((p) => p.id === suzuki.id), 'replaceでは、バックアップに無い既存データ（鈴木さん）が消える');
  assert(peopleAfterReplace.some((p) => p.id === yamada.id), 'replaceでも、バックアップに含まれるデータ（山田さん）は残る');

  console.log(`\n[test-basic] 合計: ${passCount}件成功 / ${failCount}件失敗`);
  if (failCount > 0) process.exit(1);
}

run().catch((err) => {
  console.error('[test-basic] テスト実行中にエラーが発生しました:', err);
  process.exit(1);
});
