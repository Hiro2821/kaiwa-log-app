// ============================================================
// 【テスト専用】IndexedDBの簡易スタブ（in-memory）
// ------------------------------------------------------------
// これは仕様に完全準拠したIndexedDB実装ではなく、
// Node.js環境（ネットワーク不可・実ブラウザ不可）で
// db/*.js のロジック（get/put/multiEntryインデックス/削除など）を
// オフラインで検証するための最小限のスタブである。
// 実際のSafari/IndexedDBの挙動を保証するものではない。
// ============================================================

function clone(v) {
  return v === undefined ? undefined : JSON.parse(JSON.stringify(v));
}

class FakeRequest {
  constructor() {
    this.onsuccess = null;
    this.onerror = null;
    this.result = undefined;
    this.error = null;
  }
  _succeed(result) {
    this.result = result;
    queueMicrotask(() => {
      if (this.onsuccess) this.onsuccess({ target: this });
    });
  }
  _fail(error) {
    this.error = error;
    queueMicrotask(() => {
      if (this.onerror) this.onerror({ target: this });
    });
  }
}

class FakeIndex {
  constructor(store, keyPath, options = {}) {
    this.store = store;
    this.keyPath = keyPath;
    this.multiEntry = !!options.multiEntry;
  }
  getAll(query) {
    const req = new FakeRequest();
    const results = [];
    for (const record of this.store.data.values()) {
      const val = record[this.keyPath];
      if (this.multiEntry && Array.isArray(val)) {
        if (val.includes(query)) results.push(clone(record));
      } else if (val === query) {
        results.push(clone(record));
      }
    }
    req._succeed(results);
    return req;
  }
}

class FakeObjectStore {
  constructor(keyPath) {
    this.keyPath = keyPath;
    this.data = new Map();
    this.indexes = new Map();
  }
  createIndex(name, keyPath, options) {
    const idx = new FakeIndex(this, keyPath, options);
    this.indexes.set(name, idx);
    return idx;
  }
  index(name) {
    const idx = this.indexes.get(name);
    if (!idx) throw new Error(`index not found: ${name}`);
    return idx;
  }
  add(value) {
    const req = new FakeRequest();
    const key = value[this.keyPath];
    if (this.data.has(key)) req._fail(new Error('key already exists'));
    else {
      this.data.set(key, clone(value));
      req._succeed(key);
    }
    return req;
  }
  put(value) {
    const req = new FakeRequest();
    const key = value[this.keyPath];
    this.data.set(key, clone(value));
    req._succeed(key);
    return req;
  }
  get(key) {
    const req = new FakeRequest();
    req._succeed(this.data.has(key) ? clone(this.data.get(key)) : undefined);
    return req;
  }
  getAll() {
    const req = new FakeRequest();
    req._succeed([...this.data.values()].map(clone));
    return req;
  }
  delete(key) {
    const req = new FakeRequest();
    this.data.delete(key);
    req._succeed(undefined);
    return req;
  }
  clear() {
    const req = new FakeRequest();
    this.data.clear();
    req._succeed(undefined);
    return req;
  }
  openCursor() {
    const req = new FakeRequest();
    const entries = [...this.data.entries()];
    let i = 0;
    const store = this;
    const advance = () => {
      if (i >= entries.length) {
        req._succeed(null);
        return;
      }
      const [key, value] = entries[i];
      const cursor = {
        value: clone(value),
        continue() {
          i++;
          advance();
        },
        update(newValue) {
          store.data.set(key, clone(newValue));
        },
      };
      req._succeed(cursor);
    };
    advance();
    return req;
  }
}

class FakeTransaction {
  constructor(db) {
    this.db = db;
    this._oncomplete = null;
  }
  objectStore(name) {
    return this.db.stores.get(name);
  }
  set oncomplete(fn) {
    this._oncomplete = fn;
    // 簡易スタブのため、このテストで使う範囲（呼び出し側が各リクエストを
    // 逐次awaitし終えた後にoncompleteを設定する使い方）に限り安全な近似として、
    // 設定直後の次のマイクロタスクで発火させる。
    if (fn) queueMicrotask(fn);
  }
  get oncomplete() {
    return this._oncomplete;
  }
  set onerror(fn) {
    this._onerror = fn;
  }
  get onerror() {
    return this._onerror;
  }
  set onabort(fn) {
    this._onabort = fn;
  }
  get onabort() {
    return this._onabort;
  }
}

class FakeDB {
  constructor() {
    this.stores = new Map();
    this.version = 0;
  }
  createObjectStore(name, { keyPath }) {
    const store = new FakeObjectStore(keyPath);
    this.stores.set(name, store);
    return store;
  }
  transaction() {
    return new FakeTransaction(this);
  }
}

const registry = new Map();

export function installFakeIndexedDB() {
  globalThis.indexedDB = {
    open(name, version) {
      const req = new FakeRequest();
      queueMicrotask(() => {
        let db = registry.get(name);
        const oldVersion = db ? db.version : 0;
        if (!db) {
          db = new FakeDB();
          registry.set(name, db);
        }
        if (version > oldVersion) {
          db.version = version;
          if (req.onupgradeneeded) {
            // 実際のIndexedDBでは、onupgradeneeded中は event.target.transaction 経由で
            // 「versionchangeトランザクション」を使い、既存ストアのデータ移行ができる。
            // このスタブでも同様に db.transaction() を transaction として渡す。
            req.onupgradeneeded({
              target: { result: db, transaction: db.transaction() },
              oldVersion,
              newVersion: version,
            });
          }
        }
        req._succeed(db);
      });
      return req;
    },
  };
}

export function resetFakeIndexedDB() {
  registry.clear();
}
