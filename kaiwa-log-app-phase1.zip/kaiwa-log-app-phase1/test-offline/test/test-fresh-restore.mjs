// 【テスト専用】まっさらな状態（初回起動相当）のアプリにバックアップを読み込むテスト。
// モジュールキャッシュの影響を避けるため、必ず独立したNodeプロセスとして実行すること
// （このファイル単体を `node test/test-fresh-restore.mjs` で実行する）。

import { installFakeIndexedDB } from './fakeIndexedDB.mjs';

installFakeIndexedDB();

let passCount = 0;
let failCount = 0;

function assert(condition, message) {
  if (condition) {
    passCount++;
    console.log(`  OK  ${message}`);
  } else {
    failCount++;
    console.error(`  NG  ${message}`);
  }
}

const fixtureBackup = {
  appName: 'kaiwa-log',
  exportedAt: '2026-08-01T00:00:00.000Z',
  schemaVersion: 1,
  people: [{ id: 'p1', name: '山田さん', memo: '', createdAt: '2026-07-01T00:00:00.000Z' }],
  groups: [{ id: 'g1', name: '大学の友人', memo: '', createdAt: '2026-07-01T00:00:00.000Z' }],
  records: [
    {
      id: 'r1',
      createdAt: '2026-07-02T00:00:00.000Z',
      updatedAt: '2026-07-02T00:00:00.000Z',
      personIds: ['p1'],
      groupIds: ['g1'],
      text: 'バックアップから復元されるはずの記録',
      rawVoiceText: null,
      topics: ['旅行'],
      keyPoints: [],
      nextTimeNotes: [{ id: 'n1', text: '確認事項', done: false, doneAt: null }],
      title: 'バックアップ記録',
      deletedAt: null,
    },
  ],
};

async function run() {
  const { initDB } = await import('../../kaiwa-log-app/js/db/database.js');
  const { listAllRecords } = await import('../../kaiwa-log-app/js/db/records.js');
  const { listPeople } = await import('../../kaiwa-log-app/js/db/people.js');
  const { importBackup } = await import('../../kaiwa-log-app/js/lib/backup.js');

  // アプリ起動直後（=まだ何も記録していない）を模擬
  await initDB();
  const before = await listAllRecords();
  assert(before.length === 0, '前提: 起動直後は記録が0件');

  const result = await importBackup(JSON.stringify(fixtureBackup), { mode: 'merge' });
  assert(result.recordsCount === 1, '空のアプリにバックアップを読み込める（merge）');

  const after = await listAllRecords();
  assert(after.length === 1 && after[0].text === 'バックアップから復元されるはずの記録', '読み込んだ記録の内容が正しい');

  const people = await listPeople();
  assert(people.length === 1 && people[0].name === '山田さん', '読み込んだ人物の内容が正しい');

  console.log(`\n[test-fresh-restore] 合計: ${passCount}件成功 / ${failCount}件失敗`);
  if (failCount > 0) process.exit(1);
}

run().catch((err) => {
  console.error('[test-fresh-restore] テスト実行中にエラーが発生しました:', err);
  process.exit(1);
});
