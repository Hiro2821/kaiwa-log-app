# オフライン検証用テスト（Node.js）

このフォルダは、アプリ本体（`kaiwa-log-app/`）のデータ層ロジックを
Node.js上でオフライン検証するためのものです。GitHub Pagesにアップロードする
必要はありません。

## 重要な注意

ここにあるのは実ブラウザ（Safari / IndexedDB）でのテストではありません。
IndexedDBの挙動を模した簡易スタブ（`fakeIndexedDB.mjs`）をNode.js上で動かし、
アプリのロジック（CRUD・検索・マイグレーション・バックアップなど）が
意図通り動くかどうかだけを検証しています。実機でのUI操作・iOSキーボードの
ディクテーション・実際のSafari実装でのIndexedDBの挙動は別途確認が必要です。

## 実行方法

```
cd kaiwa-log-app          # アプリ本体のフォルダ（js/ を含む）
cd ..
# このtest-offlineフォルダとkaiwa-log-appフォルダを同じ階層に置いた状態で:
node test-offline/test-basic.mjs
node test-offline/test-fresh-restore.mjs
node test-offline/test-migration.mjs
```

（相対パスの都合上、同梱の状態のまま実行してください）
